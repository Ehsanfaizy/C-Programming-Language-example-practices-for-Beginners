#include <iostream>

using namespace std;

int main()
{
   int start, last, number;
   int a;

   cout<<"\nEnter the number to calculate its table:   ";
   cin>>number;

   cout<<"\nEnter the start of the table:   ";
   cin>>start;

   cout<<"\nEnter the end of the table:  ";
   cin>>last;

   a = start;

   while ( a <= last)
   {
       cout<<number<<" * "<<a<<" = "<<number*a<<endl;
       a++;
   }
    return 0;
}
