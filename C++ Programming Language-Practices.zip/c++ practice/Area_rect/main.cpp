#include <iostream>

using namespace std;

int main()
{
  int length, breadth, area, perimeter;

  cout<<"Enter the length of a rectangle\n";
  cin>>length;

   cout<<"Enter the breadth of a rectangle\n";
   cin>>breadth;

  area = length * breadth;
  perimeter = ( 2 *length) + (2 * breadth);

  if (area > perimeter)
    cout<<"\nThe area of rectangle which is "<<area<<" is greater than its perimeter which is equal to" <<perimeter;

  else
     cout<<"\nThe area of rectangle which is "<<area<<" is smaller than its perimeter which is equal to" <<perimeter;

return 0;
}



