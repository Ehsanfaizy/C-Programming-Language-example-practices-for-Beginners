#include <iostream>

using namespace std;
//+ - * / % Operators

int main()
{
    int number1,number2,result;
    cout<<"Enter your first number"<<endl;
    cin>>number1;

    cout<<"\nEnter your second number"<<endl;
    cin>>number2;

    result = number1 + number2;
    cout<<"\nThe sum is equal to "<<result;

    result = number1 - number2;
    cout<<"\nThe difference of two numbers is equal to"<<result;

    result = number1 * number2;
    cout<<"\nThe product of two number of two equal to"<<result;

    result = number1 / number2;
    cout<<"\nThe result of division is equal to"<<result;

    result = number1 % number2;
    cout<<"\nThe remainder is equal to "<<result;

    return 0;
}
