#include <iostream>

using namespace std;

int main()
{
    int arr[5],i,sum = 0;
    for (i=0; i<5; i++)
    {
        cout<<"Enter value at array index "<<i<<":    "<<endl;
        cin>>arr[i];
        sum = sum + arr[i];
    }
    cout<<"\nThe sum of all the values stored in the array is :  "<<sum;
    return 0;
}
