#include <iostream>

using namespace std;

int main()
{
   float km,meters,feet,inches;
   cout<<"Enter the distance between two cities "<<endl;
   cin>>km;

   meters = km * 1000;
   feet = km * 3280.84;
   inches = km * 39370.1;
   cout<<"\nThe distance between two cities in meter is "<<meters;
   cout<<"\nThe distance between two cities in feet is "<<feet;
   cout<<"\nThe distance between two cities in inches is "<<inches;


    return 0;
}
