#include <iostream>

using namespace std;

int main()
{
   float costprice, saleprice,difference;
   cout<<"Please enter the cost price of an itm"<<endl;
   cin>>costprice;

   cout<<"\nplease enter the selling price of an itme "<<endl;
   cin>>saleprice;

   if (costprice > saleprice)
   {
       cout<<"\nYou have incurred a loss\n";
       difference = costprice - saleprice;
       cout<<"\nYou have incurred a loss of "<<difference;
   }
   else
    {
        cout<<"\nYou have earned a profit\n";
        difference = saleprice - costprice;
        cout<<"\nYou have earned a profit of"<<difference;
    }





    return 0;
}
