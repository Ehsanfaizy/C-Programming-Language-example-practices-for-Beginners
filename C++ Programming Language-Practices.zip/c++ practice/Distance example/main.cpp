#include <iostream>
using namespace std;
class Distance
{
private:
    int feet;
    float inches;
public: /////four member function we have
    void getDist()
    {
        cout<<"\nEnter the value of Feet:   ";
        cin>>feet;
        cout<<"\nEnter the value of Inches:   ";
        cin>>inches;
    }
    void showDist()
    {
        cout<<"\nThe value of Feet:  "<<feet;
        cout<<"\nThe value of Inches:  "<<inches;
    }
    void initialize()
    {
        feet = 0 ;
        inches = 0.0;
    }
    void setDist(int f, float i)
    {
        feet = f;
        inches = i;
    }


};
int main()
{
    Distance dist1,dist2; ///we created two obj for distance class
    dist1.initialize();
    dist2.getDist();
    cout<<"\nShowing the details of object dist1\n";
    dist1.showDist();
    cout<<"\nShowing the details of object dist2\n";
    dist2.showDist();
    return 0;
}
