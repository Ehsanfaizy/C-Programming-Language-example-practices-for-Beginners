#include <iostream>

using namespace std;

int main()
{
    float subject1, s2, s3, s4, s5, sum, percentage;

    cout<<"Enter the marks out of 100 in subject1\n";
    cin>>subject1;

    cout<<"Enter the marks out of 100 in subject2\n";
    cin>>s2;

    cout<<"Enter the marks out of 100 in subject3\n";
    cin>>s3;

    cout<<"Enter the marks out of 100 in subject4\n";
    cin>>s4;

    cout<<"Enter the marks out of 100 in subject5\n";
    cin>>s5;

    sum = subject1 + s2 + s3 + s4 + s5;

    percentage = (sum/500) * 100;
    cout<<"\nThe percentage you got is"<<percentage;

    if (percentage >= 60)
        cout<<"\nYou have got First division";

    else if (percentage >= 50 && percentage < 60)
        cout<<"\nYou have got second division";

    else if (percentage >= 40 && percentage <50)
        cout<<"\nYou have got Third division";
    else
        cout<<"\nYou have Failed";

    return 0;
}
