#include <iostream>

using namespace std;

int main()
{
   float total_salary,basic_Salary,gross_salary,medical,conveyance,house_rent,tax;
   cout<<"Enter the basic salary of Ehsan"<<endl;
   cin>>basic_Salary;

   medical = basic_Salary * 0.4;
   conveyance = basic_Salary * 0.15;
   house_rent = basic_Salary * 0.2;

   gross_salary = basic_Salary + medical + conveyance + house_rent;

   tax = gross_salary * 0.1;

   total_salary = gross_salary - tax;
   cout<<"\nThe total salary of Ehsan is"<<total_salary;







    return 0;
}
