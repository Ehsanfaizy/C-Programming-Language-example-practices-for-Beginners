#include <iostream>

using namespace std;

int main()
{
   int number;

   cout<<"Enter the number to check whether its Even or Odd number\n";
   cin>>number;

   if (number % 2 == 0)
    cout<<"\nThe number you enter was an even number";

   else
    cout<<"\nThe number yo entered was an Odd number";







    return 0;
}
