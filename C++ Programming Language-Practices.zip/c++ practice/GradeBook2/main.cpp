#include <iostream>
#include <string>
using namespace std;
class GradeBook
{
public:

void displayMessege(string courseName)
{
    cout<<"Welcome to the grade book of course "<<courseName<<endl;
}
};////class def is complete here
int main()
{
GradeBook obj;
string myCoureseName;
cout<<"Enter the name of your course "<<endl;
getline(cin,myCoureseName);
obj.displayMessege(myCoureseName);
return 0;
}
