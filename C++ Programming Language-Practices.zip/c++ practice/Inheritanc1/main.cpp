#include <iostream>
using namespace std;
///Base class
class Shape ////Base class or the parent class or the super class
{
public:
    void setWidth(int w)
    {
        width = w;
    }
    void setHeight(int h)
    {
        height = h;
    }
protected: ////protected means these data types can not access direct by object of the base class BUT CAN ACCESS by Derived object
    int width;
    int height;
};

///Derived class
class Rectangle : public Shape ///Inheritance syntex
{
public:
    int getArea()
    {
        return (width * height);
    }
};

int main(void)
{
    Rectangle Rect; ///object creation
    Rect.setWidth(5);
    Rect.setHeight(10);

    ///print the area of the object
    cout<<"Total area :  "<< Rect.getArea() <<endl;

    return 0;
}
