#include <iostream>
#include <cstdlib>
using namespace std;


int main()
{
    int number, sum=0;
    char option;
    do
    {
     system("cls");
     cout<<"Enter a positive number to find the sum of all the numbers 1 up to given number:   ";
     cin>>number;

     for(int i=1; i<=number; i++)
     {
         sum = sum + i;
     }
     cout<<"\nThe sum of all numbers starting from 1 till "<<number<<"is :   "<<sum;
     cout<<"\nDo you wish to repeat? (Press Y for yes or N for No):   ";
     cin>>option;
    }while(option=='Y' || option=='y');

    return 0;
}
