#include <iostream>
#include<cstdlib>

using namespace std;

int main()
{
    int number,factorial;/////for instance:     number=4,  factorial=1,  option=y, i=1
    char option = 'y';

    while(option == 'Y' || option == 'y')
    {
        factorial = 1;
        system("cls");
        cout<<"Enter the number to calculate its factorial:    ";
        cin>>number;
        for(int i = 1; i<=number; i++)
        {
            factorial = factorial * i ;
        }
        cout<<"\nthe factorial of "<<number<<"is equal to "<<factorial;
        cout<<"\nDo u wish repeat??? (y for yes or N for No):  ";
        cin>>option;
    }











    return 0;
}
