#include <iostream>

using namespace std;

int main()
{
    int number = 50;
    int *p;/////pointer variable (store number var address)
    p = &number; /////address of operator(assign address in p)

    cout<<"The value stored in number variable is number = "<<number<<endl;
    cout<<"The value stored in number variable is *p = "<<*p<<endl;//indirection operator

    //cout<<"The value stored in number variable is &number = "<<&number<<endl;
    //cout<<"The value stored in number variable is p = "<<p<<endl;
    number =60;
    cout<<"The value stored in number variable is number = "<<number<<endl;
    cout<<"The value stored in number variable is *p = "<<*p<<endl;//indirection operator

    *p = 100;
    cout<<"The value stored in number variable is number = "<<number<<endl;
    cout<<"The value stored in number variable is *p = "<<*p<<endl;//indirection operator





    return 0;
}
