#include <iostream>
using namespace std;
void calculatePower (int&, int&, int&);
int main()
{
    int base , power , result = 1;
    cout<<"Enter number to calculate its power:   ";
    cin>>base;
    cout<<"\nEnter power to calculate its power:   ";
    cin>>power;

    calculatePower(base,power,result);

    cout<<"\nThe power calculated is:    "<<result;
    return 0;

    return 0;
}
void calculatePower(int& b, int& p, int& r)
{
for (int i=1; i<=p; i++)
{
    r = r * b;
}
}
