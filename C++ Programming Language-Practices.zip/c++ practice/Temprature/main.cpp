#include <iostream>

using namespace std;

int main()
{
   float far,celcius;
   cout<<"Enter the temperature of a city ferahnheits "<<endl;
   cin>>far;

   celcius = (far - 32 )* 5/9;
   cout<<"The Temperature in Celcius is equal to "<<celcius;

    return 0;
}
