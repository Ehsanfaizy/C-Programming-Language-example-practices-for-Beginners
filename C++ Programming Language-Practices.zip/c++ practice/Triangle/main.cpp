#include <iostream>

using namespace std;

int main()
{
  int angle1, angle2, angle3,sum;

  cout<<"Please enter the Angle one of the triangle"<<endl;
  cin>>angle1;

  cout<<"Please enter the Angle two of the triangle"<<endl;
  cin>>angle2;

  cout<<"Please enter the Angle three of the triangle"<<endl;
  cin>>angle3;

  sum = angle1 + angle2 + angle3;

  if (sum == 180)
    cout<<"\nThe Triangle is valid triangle";
  else
     cout<<"\nThe triangle is invalid triangle";


    return 0;
}
