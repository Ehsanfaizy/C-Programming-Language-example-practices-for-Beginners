#include <iostream>
using namespace std;
void leapyear();
int main()
{
    leapyear();
    cout<<"\nI am back in main() function from leapyear() function";

    return 0;
}

void leapyear()
{
    int year;

    cout<<"Enter the year to find out if it was a leap year or not:    ";
    cin>>year;

    if(year&4 == 0)
        cout<<"\nThe year entered by you is a leap year";
    else
        cout<<"\nThe year entered by you is not a leap year";
    cout<<"\nMy user defined function leapyear() has finished";
}
