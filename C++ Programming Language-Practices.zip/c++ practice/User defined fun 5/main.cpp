#include <iostream>
using namespace std;
void calculatePower(int,int);
int main()
{
    int base,power;
    cout<<"Enter the value of base:   ";
    cin>>base;

    cout<<"\nEnter the value of power:   ";
    cin>>power;

    calculatePower(base,power);
    cout<<"\nI am back in the main() function";
    return 0;
}
void calculatePower(int a, int b)
{
    int result = 1;
    for(int i=1; i<=b;i++)
    {
        result = result * a;
    }
    cout<<"\nThe power calculated is equal to:    "<<result;
}
