#include <iostream>
using namespace std;
void sum();  ///////user defined function declaration
int main()
{
    cout<<"The program's control is in the main function\n";
    sum();////calling your user defined function
    cout<<"\nThe program's control is in the sum() function\n";
    sum();////your are calling your user defined function
    return 0;
}

void sum()  ///////user defined function definition
{
    cout<<"\nThe control of program is in the sum() function\n";
    int number1, number2, result;
    cout<<"Enter your first number:   ";
    cin>>number1;
    cout<<"\nEnter your second number:  ";
    cin>>number2;
    result = number1 + number2;
    cout<<"\nThe result of adding to numbers is:   "<<result;
    cout<<"\nThe sum function has concluded, the program control will get back to main function\n";
}
