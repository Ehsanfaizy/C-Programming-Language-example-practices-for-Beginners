#include <iostream>
using namespace std;
void power();
int main()
{
    power();
    cout<<"\nI am inside the main function and back fro the power function";
    return 0;
}



void power()
{
    int base, p, answer=1;
    cout<<"\nEnter the base number to calculate it's power:   ";
    cin>>base;
    cout<<"\nEnter the power number:    ";
    cin>>p;

    for(int i=1; i<=p; i++)
    {
        answer = answer * base;
    }
    cout<<"\nThe power calculated was equal to :    "<<answer;
}
