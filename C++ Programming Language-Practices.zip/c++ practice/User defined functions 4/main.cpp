#include <iostream>
using namespace std;
void sum(int,int);
int main()
{
    int number1, number2;
    cout<<"Enter first number:   ";
    cin>>number1;

    cout<<"\nEnter second number:  ";
    cin>>number2;

    sum (number1,number2);//////Actual arguments
    cout<<"\nI am back in the main() function";
    return 0;
}

void sum(int a, int b)////Formal arguments
{
    int result = a + b;
    cout<<"\nThe result of adding two number is:    "<<result;
}
