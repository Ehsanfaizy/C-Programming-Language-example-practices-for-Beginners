#include <iostream>

using namespace std;

int main()
{
    ////int myArray[5] = {1,2,3,4,5};////declaration iniasalize
     ////int myArray[] = {1,2,3,4,5};////declaration

     ///int myArray[5];
     //myArray[0] = 10;
     //myArray[1] = 50;
     //myArray[2] = 70;
     ///myArray[3] = 60;
     ///myArray[4] = 80;

     //cout<<myArray[0]<<endl;
     //cout<<myArray[1]<<endl;
     ///cout<<myArray[2]<<endl;
     ///cout<<myArray[3]<<endl;
     ///cout<<myArray[4]<<endl;

     int myArray[5], i;
     for(i=0; i<5; i++)
     {
         cout<<"Enter value at array index "<<i<<":   ";
         cin>>myArray[i];
         cout<<endl;
     }
     for (i = 0; i<5; i++)
     {
         cout<<"The value present at index number   "<<i<<" is "<<myArray[i]<<endl;
     }


    return 0;
}
