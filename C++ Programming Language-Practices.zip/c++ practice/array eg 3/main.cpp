#include <iostream>
using namespace std;

int main()
{
    //// Ten numbers are entered from the keyboard into a array.The number to be searched is also entered through the keyboard by the user.
    ////write a program to find if the number to be searched is present in the array and if it is present, display the  number of times
    ////it appears in the array.

    int myArr[10];
    int counter;
    int number;
    int times = 0;

    for (counter=0; counter<10; counter++)
    {
        cout<<"\Enter value at index "<<counter<<":   ";
        cin>>myArr[counter];
    }
    cout<<"\nEnter a number to search in the array:   ";
    cin>>number;

    for(counter=0; counter<10; counter++)
    {
        if (number == myArr[counter])
        {
            times++;
        }
    }
    if (times > 0)
    {
        cout<<"\nThe number was present on array"<<endl;
        cout<<"\nThe number was present "  <<times<<"  number of times ";
    }
    else
    {
        cout<<"\nThe number which u wanted to search in array not found";
    }
    return 0;
}
