#include <iostream>

using namespace std;

int main()
{
    ///Ten numbers are entered from keyboard into array .write a program to find out how many of them are positive, negative, even and odd.
   int myArray[10];
   int counter;
   int neg=0, pos=0, even=0, odd=0;

   for (counter<0; counter<10; counter++)
   {
       cout<<"Enter the value at index:     "<<counter<<endl;
       cin>>myArray[counter];
       if (myArray[counter] >= 0)
       {
           pos++;
           if (myArray[counter] % 2 == 0)
           {
               even++;
           }
           else
            odd++;
       }
       if (myArray[counter] < 0)
       {
           neg++;
           if (myArray[counter] % 2 == 0)
           {
               even++;
           }
           else
            odd++;
       }
   }
   cout<<"\nThe total number of positive numbers in the array were:  "<<pos;
   cout<<"\nThe total number of negative numbers in the array were:  "<<neg;
   cout<<"\nThe total number of even numbers in the array were:      "<<even;
   cout<<"\nThe total number of odd numbers in the array were:       "<<odd;




    return 0;
}
