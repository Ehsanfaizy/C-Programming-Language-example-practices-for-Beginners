#include <iostream>

using namespace std;

int main()
{
    //// write a c++ program to copy all elements from an array to another array.
    int array1[5],array2[5];
    int i;
    for(i=0; i<5; i++)
    {
        cout<<"\nEnter value at array index "<<i<<":   ";
        cin>>array1[i];

        array2[i] = array1[i];
    }
    cout<<"\nValues of array1 and array2 are printed below\n";
    for (i=0; i<5; i++)
    {
    cout<<array1[i]<<" "<<array2[i]<<endl;
    }
    return 0;
}
