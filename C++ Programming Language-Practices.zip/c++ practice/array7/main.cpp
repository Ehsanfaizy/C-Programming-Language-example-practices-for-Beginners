#include <iostream>

using namespace std;

int main()
{
////write a c++ program to count total number of even and odd elements in an array.

    int myArray[5];
    int even=0, odd=0;
    int i;

    for (i=0; i<5 ;i++)
    {
        cout<<"enter value at index "<<i<<":   ";
        cin>>myArray[i];

        if (myArray[i]% 2 == 0)
            even++;
        else
            odd++;
    }
    cout<<"\nThe total number of even numbers in the array were:   "<<even;
    cout<<"\nThe total number of odd numbers in the array were:   "<<odd;
    return 0;
}
