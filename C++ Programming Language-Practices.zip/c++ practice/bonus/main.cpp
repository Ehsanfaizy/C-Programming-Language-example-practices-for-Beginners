#include <iostream>

using namespace std;

int main()
{
  int current_year, joining_year, service_year,bonus;
  cout<<"Please enter the current year"<<endl;
  cin>>current_year;

  cout<<"\nPlease enter the year of joining"<<endl;
  cin>>joining_year;

  service_year = current_year - joining_year;

  if(service_year > 3)
   {
       bonus = 2500;
       cout<<"\nThe Bonus is given to the employee is equal to"<<bonus;

   }






    return 0;
}
