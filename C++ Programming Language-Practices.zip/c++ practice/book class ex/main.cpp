#include <iostream>

using namespace std;
class book
{
  private:
      char name[25];
      int pages;
      float price;
  public:
    void setName (char *n){
    strcpy(name, n);
    }
    void setPages(int p){
        pages = p;
    }
    void setPrice(float p){
        price = p;
    }
    void display(){
        cout<<"name = "<<name<<"pages = "<<pages;
        cout<<"Price = "<<price<<endl;
    }
    };
int main()
{
    Book b1;
    b1.setPages(50);
    b1.setPrice(120.55);
    b1.setName("Operating Systems";)
    b1.display();
    return 0;
}
