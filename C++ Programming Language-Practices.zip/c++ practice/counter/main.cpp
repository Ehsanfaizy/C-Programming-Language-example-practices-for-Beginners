#include <iostream>

using namespace std;
class Counter
{
private:
    int count;
public:
    Counter() : count(0)
    {
        ///count = 0;
        cout<<"\nConstructor called";
    }
    void inc_count()
    {
        count++;
    }
    int get_count()
    {
        return count;
    }
};
int main()
{
   Counter c1,c2,c3;
   c1.inc_count();
   c2.inc_count();
   c2.inc_count();
   c2.inc_count();
   cout<<"\nThe value of count variable of c1 object is "<<c1.get_count();
   cout<<"\nThe value of count variable of c2 object is "<<c2.get_count();
   cout<<"\nThe value of count variable of c3 object is "<<c3.get_count();
   return 0;
}
