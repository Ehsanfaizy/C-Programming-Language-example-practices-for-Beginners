#include <iostream>
#include <stdlib.h>

using namespace std;

int main()
{
   int number1, number2;
   char choice;

   do
   {
       system("cls");
       cout<<"Enter the first number:    ";
       cin>>number1;

       cout<<"\nEnter the second number:    ";
       cin>>number2;

       cout<<"\nThe sum of the number is equal to "<<number1 + number2<<endl;
       cout<<"\nThe differnce of the number is equal to "<<number1 - number2<<endl;
       cout<<"\nThe product of the number is equal to "<<number1 * number2<<endl;
       cout<<"\nThe division of the number is equal to "<<number1 / number2<<endl;
       cout<<"\nDo you wish to repeat ? (press Y for yes or N for no)"<<endl;
       cin>>choice;
   }while (choice == 'y' || 'Y');
   cout<<"\nThe program will terminate now .......";

    return 0;
}
