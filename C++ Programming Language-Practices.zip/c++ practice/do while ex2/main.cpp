#include <iostream>

using namespace std;

int main()
{
    int a = 0;
     int sum = 0;

    do
    {
     sum = sum + a;
        a = a+2;
    }while(a <= 10);

    cout<<"\nThe sum of even is equal to "<<sum;

    return 0;
}
