#include <iostream>

using namespace std;

int main()
{
    int a  = 1;

    do
    {
        cout<<a<<endl;
        a = a + 2;
    }while(a<=7);


    return 0;
}
