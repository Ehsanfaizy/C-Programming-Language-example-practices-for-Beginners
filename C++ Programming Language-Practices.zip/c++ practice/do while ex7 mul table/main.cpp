#include <iostream>

using namespace std;

int main()
{
    int a;
    int start, last;
    int number;

    cout<<"Enter number to generate  its table:   ";
    cin>>number;

    cout<<"\nStaring value:   ";
    cin>>start;

    cout<<"\nLast or ending value:   ";
    cin>>last;


    a = start;

    do
    {
        cout<<number<<" * "<<a<<" = "<<number*a<<endl;
        a++;
    }while (a <= last);

    return 0;
}
