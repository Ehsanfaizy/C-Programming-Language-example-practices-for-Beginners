#include <iostream>

using namespace std;

int main()
{
    int a = 0;

    do
    {
        cout<<"Hospital\n";
        a++;
    }while(a<5);

    return 0;
}
