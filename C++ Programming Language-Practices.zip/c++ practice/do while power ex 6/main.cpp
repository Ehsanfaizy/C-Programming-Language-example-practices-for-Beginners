#include <iostream>

using namespace std;

int main()
{
    int a = 1;
    int base,power;

    int result = 1;

    cout<<"Enter the value of base:   ";
    cin>>base;

    cout<<"\nEnter the value of power:   ";
    cin>>power;


    do

    {
        result = result * base;
        a++;
    }while (a <= power);

    cout<<"\nThe power calculated is equal to "<<result;



    return 0;
}
