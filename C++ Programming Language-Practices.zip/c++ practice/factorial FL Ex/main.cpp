#include <iostream>

using namespace std;

int main()
{
    unsigned long int factorial = 1;

    for (int a = 1; a<= 5; a++)
    {
        factorial = factorial * a;
    }
    cout<<"The Factorial of number five is equal to\n"<<factorial;


    return 0;
}

