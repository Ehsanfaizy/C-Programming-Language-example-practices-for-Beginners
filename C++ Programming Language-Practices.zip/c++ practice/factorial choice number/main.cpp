#include <iostream>

using namespace std;

int main()
{
    unsigned long int factorial = 1;
    int number;

    cout<<"Enter the number to calculate its factorial   :";
    cin>>number;

    for (int a = 1; a<= number; a++)
    {
        factorial = factorial * a;
    }
    cout<<"The Factorial of " <<number<< " is equal to\n"<<factorial;
    return 0;
}
