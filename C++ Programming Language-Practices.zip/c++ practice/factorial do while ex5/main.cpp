#include <iostream>

using namespace std;

int main()
{
    int a = 1;
    unsigned long int factorial = 1;
    int number;

    cout<<"Enter a positive number to calculate its factorial\n";
    cin>>number;

    do
    {
        factorial = factorial * a;
        a++;
    }while(a <= number);

    cout<<"\nThe factorial of"<<number<<"is equal to   "<<factorial;







    return 0;
}
