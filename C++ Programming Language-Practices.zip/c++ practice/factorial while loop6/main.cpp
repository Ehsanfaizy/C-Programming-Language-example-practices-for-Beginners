#include <iostream>

using namespace std;

int main()
{
    int number, a=1;
    unsigned long int factorial = 1;

    cout<<"Enter the number to calculate its factorial:  ";
    cin>>number;

    while(a <= number)
    {
        factorial = factorial * a;
        a++;
    }
    cout<<endl<<"The factorial of"<<number<<" is: "<<factorial;


    return 0;
}
