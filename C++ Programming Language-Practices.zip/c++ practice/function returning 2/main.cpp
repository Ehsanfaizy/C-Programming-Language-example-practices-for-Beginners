#include <iostream>

using namespace std;
unsigned int factorial();
int main()
{
    unsigned int fact;

    fact = factorial();
    cout<<"\nEqual: "<<fact;
    return 0;
}
unsigned int factorial()
{
    int number;
    unsigned int f = 1;

    cout<<"\nEnter the number:   ";
    cin>>number;
    for(int i = 1; i<=number;i++)
    {
        f = f * i;
    }
    return f;
}
