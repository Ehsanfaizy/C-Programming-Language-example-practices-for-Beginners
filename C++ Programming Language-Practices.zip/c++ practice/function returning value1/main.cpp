#include <iostream>
using namespace std;
int sum();
int main()
{
    int answer;
    cout<<"You are inside the main function\n";
    answer = sum();
    cout<<"\nThe control is back into the main function\n";
    cout<<"\nThe sum of two given number is equal to:   "<<answer;
    return 0;
}
int sum()
{
    int number1,number2,result;
    cout<<"\nEnter first number:  ";
    cin>>number1;
    cout<<"\nEnter secon number:  ";
    cin>>number2;

    result = number1 + number2;
    return result;
}
