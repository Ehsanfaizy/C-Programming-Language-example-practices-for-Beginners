#include <iostream>

using namespace std;

int main()
{
    ///ha

    int rows;

    cout<<"Enter the number of rows in your half pyramid:   ";
    cin>>rows;

    for (int i=1; i <= rows; i++)
    {
        for(int j=1; j <= i; j++)
        {
            cout<<"*";
        }
        cout<<"\n";
    }





    return 0;
}
