#include <iostream>

using namespace std;

int main()
{
    int quantity;
    float price, expenses,discount = 0;

    cout<<"Enter the quantity of purchaed"<<endl;
    cin>>quantity;

    cout<<"\nEnter the price if item"<<endl;
    cin>>price;


    if(quantity > 1000)
        discount = 0.1;
    expenses = (quantity * price) - (quantity * price * discount);

    cout<<"\nYour total is expenses after giving you a discount of "<<discount<<" is equal to "<<expenses;



    return 0;
}
