#include <iostream>

using namespace std;

int main()
{
    int number;

    cout<<"Enter any number of your own choice\n";
    cin>>number;

    if (number == 0)
    {
        cout<<"\nThe number you entered was zero";
    }
    else if (number > 0)
    {
        cout<<"\nThe number you have entered was greater than zero and positive number";
    }
    else
    {
        cout<<"\nThe number you entered was less than zero and a was a negative number\n";
    }




    return 0;
}
