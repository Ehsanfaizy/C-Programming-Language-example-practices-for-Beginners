#include <iostream>

using namespace std;

int main()
{
    int number1, number2, result;
    char operation;

    cout<<"Please enter your first number\n";
    cin>>number1;

    cout<<"\nPlease enter your second number\n";
    cin>>number2;

    cout<<"\nEnter the symbol to perform the operation(+,-,*,/,%)";
    cin>>operation;

    if(operation == '+')
    {
        result = number1 + number2;
        cout<<"\nThe result of addition operation is equal to"<<result;
    }
    else if (operation == '-')
    {
        result = number1 - number2;
        cout<<"\nThe result of subtraction operation is equal to"<<result;
    }
    else if (operation == '*')
    {
        result = number1 * number2;
        cout<<"\nThe result of multiplication operation is equal to"<<result;
    }
    else if(operation == '/')
    {
        result = number1 / number2;
        cout<<"\nThe result of division operation is equal to"<<result;
    }
    else if (operation == '%')
    {
        result = number1 % number2;
        cout<<"\nThe result of modules operation is equal to"<<result;
    }
    else
    {
        cout<<"\nPlease type a correct operator the program will terminate";
    }
    return 0;
}
