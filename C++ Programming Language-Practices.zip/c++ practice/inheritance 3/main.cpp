#include <iostream>
using namespace std;
class base{
int i , j;
public:
    void set(int a, int b)
    {
        i = a;
        j = b;
    }
    void show()
    {
        cout<<i<<" "<<j<<endl;
    }
};
///inheritance
class derived : public base{
int k;
public:
    derived(int x){ k = x; }
    void showk(){ cout<<k<<endl; }
};
int main(){
derived obj(4);
obj.set(1,2);
obj.show();

obj.showk();
return 0 ;
}
