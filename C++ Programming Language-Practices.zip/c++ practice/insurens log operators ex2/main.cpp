#include <iostream>

using namespace std;

int main()
{
    int age;
    char gender, marital_status;
    cout<<"please enter the age of driver"<<endl;
    cin>>age;

    cout<<"\nplease enter the gender of driver\n";
    cin>>gender;

    cout<<"\nplease enter the marital status of driver U for unmarried and M for married\n";
    cin>>marital_status;

    if ((marital_status == 'M') || (marital_status == 'U' && gender == 'M' && age > 30) || (marital_status == 'U' && gender == 'F' && age > 25))
        cout<<"\nThe driver should be insured";
    else
        cout<<"\nThe driver should not be insured";


    return 0;
}
