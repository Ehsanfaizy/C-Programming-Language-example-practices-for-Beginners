#include <iostream>

using namespace std;

int main()
{
    int days, total_fine;

    cout << "Enter the total number of days that a member is late to return the book\n";
    cin>>days;

    if (days <= 5)
    {
    total_fine = days * 5;
    cout<<"\n Your total fine due is "<<total_fine;
    }
    else if (days > 5 && days <= 10)
    {
        total_fine = days * 10;
        cout<<"\n Your total fine due is "<<total_fine;
    }
    else if (days > 10 && days <= 30 )
       {
        total_fine = days * 20;
        cout<<"\n Your total fine due is "<<total_fine;
       }
    else
    {
        total_fine = days * 20;
        cout<<"\n Your total fine due is "<<total_fine;
        cout<<"\n Your Library membership is canceled becouse you return the book after 30 days late ";
    }

    return 0;
}
