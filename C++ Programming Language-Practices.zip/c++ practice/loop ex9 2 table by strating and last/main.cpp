#include <iostream>

using namespace std;

int main()
{
   int start, last, number;

   cout<<"Enter the number to print its table";
   cin>>number;

   cout<<"Enter the start value";
   cin>>start;

   cout<<"\nEnter the last value";
   cin>>last;

   for (int a=start; a<=last; a++)
   {
       cout<<number<<" * "<<a<<" = "<<number*a<<endl;
   }
    return 0;
}
