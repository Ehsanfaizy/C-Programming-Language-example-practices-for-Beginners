#include <iostream>

using namespace std;

int main()
{
    for (int i = 1; i<=10; i++)
    {
        cout<<"2 * "<< i << " = "<<2*i<<endl;
    }

    for (int n=1; n<=10; n++)
    {
        cout<<"\n3 * "<<n<<" = "<<3*n<<endl;
    }

    for (int m=1; m<=10; m++)
    {
        cout<<"\n4 * "<<m<<" = "<<4*m<<endl;
    }

    for (int x=1; x<=10; x++)
    {
        cout<<"\n5 * "<<x<<" = "<<5*x<<endl;
    }
    for (int y=1; y<=10; y++)
    {
        cout<<"\n6 * "<<y<<" = "<<6*y<<endl;
    }
    return 0;
}










