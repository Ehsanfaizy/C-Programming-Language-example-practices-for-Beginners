#include <iostream>

using namespace std;

int main()
{
   for (int i = 0; i < 10; i++)/////////////////// i = 0
   {
       cout<<"\nALLAH AKBAR\n";
       /////////cout<<i<<endl;
   }

    return 0;
}
