#include <iostream>

using namespace std;

int main()
{
  cout<<"Number\tSquare of Number";
  for (int i=0;i<10;i++)
    {
    cout<<i<<"\t"<<i*i<<endl;
    }

    return 0;
}
