#include <iostream>

using namespace std;

int main()
{

      for (int i=0; i<=10; i=i+2)
    {
        cout<<i<<"\t"<<endl;
    }




    return 0;
}
