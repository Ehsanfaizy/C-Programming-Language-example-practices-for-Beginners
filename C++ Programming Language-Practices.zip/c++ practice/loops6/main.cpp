#include <iostream>

using namespace std;

int main()
{
    int sum = 0;
    for (int i=10; i<=20; i=i+2)
    {
        sum = sum + i;
    }
    cout<<"The sum of all the numbers between 10 and 20 is equal to"<<sum;
    return 0;
}
