#include <iostream>

using namespace std;

int main()
{
   int sum = 0;////////////start = 10 last=15 sum=0 a=1-->start is 10
   int start,last;

   cout<<"Enter the starting number of your series to calculate the sum\n";
   cin>>start;

   cout<<"\nEnter the last number of your series to calculate the sum\n";
   cin>>last;

   for (int a=start; a<=last; a++)
   {
       sum = sum + a;
   }
   cout<<"The sum of all the number between"<<start<<"and"<<last<<" is equal to"<<sum;



    return 0;
}
