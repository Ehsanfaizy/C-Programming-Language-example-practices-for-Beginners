#include <iostream>

using namespace std;

int main()
{
    float subject1,subject2,subject3,subject4,subject5,total,percentage;
    cout<<"\nEnter marks for subject one"<<endl;
    cin>>subject1;

    cout<<"\nEnter marks for subject two"<<endl;
    cin>>subject2;

    cout<<"\nEnter marks for subject three"<<endl;
    cin>>subject3;

    cout<<"\nEnter marks for subject four"<<endl;
    cin>>subject4;

    cout<<"\nEnter marks for subject five"<<endl;
    cin>>subject5;

    total = subject1 + subject2 + subject3 + subject4 + subject5;
    percentage = (total / 500) * 100;

    cout<<"\nThe total marks of student is equal to"<<total;
    cout<<"\nThe percentage of the student is equal to"<<percentage;
    return 0;
}
