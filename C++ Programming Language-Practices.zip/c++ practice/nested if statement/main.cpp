#include <iostream>

using namespace std;

int main()
{
  int number;
  cout<<"Enter a number of your own choice between 1 and 999\n";
  cin>>number;

  if(number > 0)
  {
      cout<<"\nThe number you entered was a positive number\n";
      if (number < 10)
        cout<<"\nThe number you entered was less than 10 and it was a single digit number";
       else if (number < 100)
        cout<<"\nThe n u ent lss 100 and dbl dgt num";
       else if (number < 1000)
        cout<<"\nThe n u ent less 1000 and three digits";
       else
        cout<<"\nyou entered a num greater than 999";
  }
  else if (number == 0 )
        cout<<"\nThe number u entered was equal to zero try again";
  else
        cout<<"\nThe number you entered was less than zero try again";


    return 0;
}
