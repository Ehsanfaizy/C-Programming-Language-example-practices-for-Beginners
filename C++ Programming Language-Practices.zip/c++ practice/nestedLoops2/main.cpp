#include <iostream>

using namespace std;

int main()
{
    int base,power;
    int result=1;
    char option = 'y';
    while(option=='y' || option=='Y')
    {
        system("cls");
        cout<<"The the base to calculate its power:   ";
        cin>>base;

        cout<<"\nEnter the power of base:   ";
        cin>>power;

        for(int i=1; i <= power; i++)
        {
            result = result * base;
        }
        cout<<"The answer is:   "<<result;

        cout<<"\nDo you wish to continue?  (y for yes and N for no):  ";
        cin>>option;
    }









    return 0;
}
