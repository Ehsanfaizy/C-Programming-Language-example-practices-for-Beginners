#include <iostream>
using namespace std;
class objpart
{
private:
    int modelnumber, partnumber;
    float cost;
public:
    void setpart(int mn, int pn, float c)
    {
        modelnumber = mn;
        partnumber = pn;
        cost = c;
    }
     void showpart()
     {
         cout<<"model "   <<modelnumber;
         cout<<"part number  "<<partnumber;
         cout<<"cost $  " <<cost<<endl;
     }
       void showpart2()
     {
         cout<<"model "   <<modelnumber<<endl;
         cout<<"part number  "<<partnumber<<endl;
         cout<<"cost $  " <<cost<<endl;
     }
};
int main()
{
  objpart part1;
  objpart part2;
  part1.setpart(6244, 373, 217.998);
  part1.showpart();
  part2.setpart(400, 500, 40.785);
  part2.showpart2();
  return 0;
}
