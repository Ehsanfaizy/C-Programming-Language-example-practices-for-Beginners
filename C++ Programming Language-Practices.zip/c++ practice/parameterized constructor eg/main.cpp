#include <iostream>
using namespace std;

class xyz
{
public:
    int a;
    xyz(int x) ////parameterized constructor which initialize value automatically when objects created
    {
        a = x;
    }
};
int main()
{
    xyz obj1(10);
    xyz obj2(20);
    xyz obj3(30);
    cout<<obj1.a<<endl<<obj2.a<<endl<<obj3.a;

    return 0;
}

