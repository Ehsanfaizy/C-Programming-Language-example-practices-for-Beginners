#include <iostream>
using namespace std;
class car
{
public:
    string brand;
    string model;
    int year;
    car(string x, string y, int z)
    {
        brand = x;
        model = y;
        year = z;
    }
};
int main()
{
    car obj1("Land Cruiser","V8", 2023);
    car obj2("BMW", "4X", 2016);
    car obj3("4Runner", "Full Option", 2016);

    cout<<"Mortaza will have : "<<obj1.brand<<" "<<obj1.model<<" "<<obj1.year<<"\n"<<endl;
    cout<<obj2.brand<<" "<<obj2.model<<" "<<obj2.year<<"\n"<<endl;
    cout<<"I will have a : " <<obj3.brand<<endl<<obj3.model<<endl<<obj3.year<<endl;
    return 0;
}

