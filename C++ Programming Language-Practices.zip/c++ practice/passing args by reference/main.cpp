#include <iostream>
using namespace std;
void swapValues(int&,int&);
int main()
{
    int number1,number2;
    cout<<"Enter value in number1 var:    ";
    cin>>number1;

    cout<<"Enter value in number2 var:    ";
    cin>>number2;

    cout<<"\nThe value of number1 before swapping :   "<<number1;
    cout<<"\nThe value of number1 before swapping :   "<<number2;

    swapValues(number1,number2);

    cout<<"\nThe value of number1 after swapping :   "<<number1;
    cout<<"\nThe value of number2 after swapping :   "<<number2;
    return 0;
}
void swapValues(int& number1Ref, int& number2Ref)
{
    int temp;

    temp = number1Ref;
    number1Ref = number2Ref;
    number2Ref = temp;
}
