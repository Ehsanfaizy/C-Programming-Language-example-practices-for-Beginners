#include <iostream>
#include <stdlib.h>
using namespace std;

struct Rectangle
{
    int lenght;
    int breadth;
};
int main()
{
    /*Rectangle r = {10,5};
    cout<<r.lenght<<endl;
    cout<<r.breadth<<endl;

    Rectangle *p = &r;
    */

    ///HEAP ALLOCATION
    Rectangle *p;

    // This is in C language p = (struct Rectangle *)malloc(sizeof(struct Rectangle));

    //in C++
    p = new Rectangle;

    p->lenght=100;
    p->breadth=200;

    cout<<p->lenght<<endl; //for pointer we use -> this arrow
    cout<<p->breadth<<endl;


    return 0;
}
