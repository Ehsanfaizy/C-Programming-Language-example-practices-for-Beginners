#include <iostream>
using namespace std;

class Animal ///base class
{
public:
    void animalsound()
    {
        cout<<"The animal makes a sound \n";
    }
};
class cat : public Animal  ///derived class
{
    public:
        void animalsound()
        {
            cout<<"The cat says : meaw meaw \n";
        }
};
class dog : public Animal ///derived class
{
public:
    void animalsound()
    {
        cout<<"The dog says : wow wow\n";
    }
};
int main()
{
    Animal myAnimal;
    cat mycat;
    dog mydog;

    myAnimal.animalsound();
    mycat.animalsound();
    mydog.animalsound();
    return 0;
}
