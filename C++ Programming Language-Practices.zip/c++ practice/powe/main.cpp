#include <iostream>

using namespace std;

int main()
{
    int result = 1;
    int base, power;

    cout<<"Enter the base value to calculate its power:    ";
    cin>>base;

    cout<<"\nEnter the power value:   ";
    cin>>power;


    for (int a=1; a <= power; a++)
    {
        result = result * base;
    }

    cout<<base<<"power"<<power<<" is equal to :  "<<result;


    return 0;
}
