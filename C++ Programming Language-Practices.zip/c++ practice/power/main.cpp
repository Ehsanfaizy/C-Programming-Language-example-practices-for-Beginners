#include <iostream>

using namespace std;

int main()
{
    int base, power, result = 1, a;

    cout<<"Enter the base value to calculate its power:   ";
    cin>>base;

    cout<<"\nEnter the power value:   ";
    cin>>power;

    a = 1;

    while (a <= power)
    {
        result = result * base;
        a++;
    }
    cout<<endl<<result;

    return 0;
}
