#include <iostream>
using namespace std;

///Tail Recursion
void fun1(int n)
{
    if (n>0)
    {
        ///printf("%d ",n); OUTPUT 3 2 1
        fun1(n-1);
        printf("%d ",n);   ///OUTPUT 123
    }
}


int main()
{
    int x=3;
    fun1(x);
    return 0;
}
