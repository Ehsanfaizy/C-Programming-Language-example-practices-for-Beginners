#include <iostream>

using namespace std;

int main()
{
    int number;
    int& numberRef = number;

    number = 10;
    cout<<"The value stored in number V is equal to:   "<<number;
    cout<<"\nThe value stored in number V is equal to:   "<<numberRef;

    numberRef = 50;
    cout<<"\nThe value stored in number V is equal to:   "<<number;
    cout<<"\nThe value stored in number V is equal to:   "<<numberRef;

    return 0;
}
