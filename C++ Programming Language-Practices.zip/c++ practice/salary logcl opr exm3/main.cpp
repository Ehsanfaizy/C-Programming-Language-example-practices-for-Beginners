#include <iostream>

using namespace std;

int main()
{
   char gender, qualification;
   int service, salary;

   cout<<"Enter the value of employee's gender (M for male and F for female)\n";
   cin>>gender;

   cout<<"\nEnter the Employee's qualification (P for Post-graduate and G from Graduate\n";
   cin>>qualification;

   cout<<"\nEnter the Employee's year of service\n";
   cin>>service;

   if (gender == 'M' && service >= 10 && qualification == 'P')
       salary = 15000;
   else if ((gender == 'M' && service >= 10 && qualification == 'G') || (gender =='M' && service < 10 && qualification == 'P'))
       salary = 10,000;
   else if (gender == 'M' && service < 10 && qualification == 'G')
       salary = 7000;
   else if (gender == 'F' && service >= 10 && qualification == 'P')
       salary = 12000;
   else if (gender == 'F' && service >= 10 && qualification == 'G')
       salary = 9000;
   else if (gender == 'F' && service < 10 && qualification == 'P')
       salary = 10000;
   else if (gender == 'F' && service < 10 && qualification == 'G')
       salary = 6000;

   cout<<"\nSalary of the Employee according to rules is equal to "<<salary;

    return 0;
}
