#include <iostream>

using namespace std;

int main()
{
    float salary, da, hra, gross_salary;

    cout<<"Enter the basic salary of the employee\n";
    cin>>salary;

    if (salary < 1500)
    {
       hra =0.1 * salary;
       da  = 0.9 * salary;
       gross_salary = salary + hra + da;
    }
    else
    {
        hra = 500;
        da = 0.98 * salary;
        gross_salary = salary + hra+ da;
    }

    cout<<"\nThe gross salary of the employee is equal to "<<gross_salary;

    return 0;
}
