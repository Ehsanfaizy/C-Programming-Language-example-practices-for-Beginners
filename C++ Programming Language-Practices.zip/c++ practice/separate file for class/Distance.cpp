#include "Distance.h"
Distance::Distance()
{
    feet = 0 ;
    inches = 0;
}
void Distance :: setDist(int f,float i)
{
    feet = f;
    inches = i;
}

void Distance ::getDist()
{
    cout<<"\nEnter the value of Feet:   ";
    cin>>feet;
    cout<<"\nEnter the value of Inches:   ";
    cin>>inches;
}

void Distance :: showDist()
{
    cout<<"\nThe value of Feet:  "<<feet;
    cout<<"\nThe value of Inches:  "<<inches;
}
