#ifndef DISTANCE_H
#define DISTANCE_H
#include <iostream>
using namespace std;
class Distance
{
    public:
        Distance();
        void setDist(int,float);
        void getDist();
        void showDist();
    private:
        int feet;
        float inches;
};

#endif // DISTANCE_H
