#include "Distance.h"
int main()
{
    Distance dist1,dist2; ///we created two obj for distance class
    //dist1.initialize();
    dist2.getDist();
    cout<<"\nShowing the details of object dist1\n";
    dist1.showDist();
    cout<<"\nShowing the details of object dist2\n";
    dist2.showDist();

    return 0;
}
