#include <iostream>
#include <string>
using namespace std;
class GradeBook
{
private:
string courseName;
public:

void setCourseName(string n)
{
courseName = n;
}
string getCOurseName()
{
    return courseName;
}
void display()
{
    cout<<"The name of course is "<<getCOurseName();
}};

int main()
{
GradeBook obj;
string course;
cout<<"Enter the name of course for object obj"<<endl;
getline(cin,course);
obj.setCourseName(course);
obj.display();
return 0;
}
