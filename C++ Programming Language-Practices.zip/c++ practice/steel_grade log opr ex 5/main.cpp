#include <iostream>

using namespace std;

int main()
{
    int hardness, testile_strenght;
    float carbon_content;


    cout<<"Enter the value of Hardness of your steel\n";
    cin>>hardness;

    cout<<"\nEnter the the value of testile_strenght of your steel\n";
    cin>>testile_strenght;

    cout<<"\nEnter the value of Carbon content of your steel\n";
    cin>>carbon_content;

   if (hardness > 50 && testile_strenght > 5600 && carbon_content < 0.7)
        cout<<"\nThe grade of your steel is 10";
   else if (hardness > 50 && carbon_content < 0.7)
        cout<<"\nThe grade of your steel is 9";
   else if (carbon_content < 0.7 && testile_strenght > 5600);
        cout<<"\nThe grade of your steel is 8";
   else if (hardness > 50 && testile_strenght > 5600)
        cout<<"\nThe grade of your steel is 7";
   else if (hardness > 50 || carbon_content < 0.7 || testile_strenght > 5600)
        cout<<"\nThe grade of your steel is 6";
   else
        cout<<"\nThe grade of your steel is 5";

    return 0;
}
