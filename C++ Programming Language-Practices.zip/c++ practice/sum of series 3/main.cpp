#include <iostream>

using namespace std;

int main()
{
    ///(1*1)+(2*2)+(3*3)+(4*4)+...
    int counter;
    int sum = 0;
    int terms;

    cout<<"Enter the number of terms to calculate its sum:    ";
    cin>>terms;
    for(counter= 1; counter<=terms; counter++)
    {
        sum = sum + (counter * counter);
    }
    cout<<"\nThe sum of all the terms of your series is:    "<<sum;


    return 0;
}
