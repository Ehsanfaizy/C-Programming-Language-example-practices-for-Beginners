#include <iostream>

using namespace std;

int main()
{
    ///(1*2*3)+(2*3*4)+(3*4*5)+....

    int sum = 0;
    int terms;
    int counter;

    cout<<"Enter the number of terms to calculate its sum:   ";
    cin>>terms;

    for (counter=1; counter<=terms; counter++)
    {
        sum = sum + (counter *(counter + 1) * (counter + 2));
    }
    cout<<"\nThe sum of all given terms of the series is:   "<<sum;


    return 0;
}
