#include <iostream>

using namespace std;

int main()
{
    ///1+1/2*2+1/3*3/4*4+1/5*4+.....

    float sum=0 , counter;
    int terms;

    cout<<"Enter the number of term to calculate its sum:     ";
    cin>>terms;

    for (counter=1; counter<=terms; counter++)
    {
        sum = sum + 1 /(counter * counter);
    }
    cout<<"\nSum of all the given terms of series is:     "<<sum;

    return 0;
}
