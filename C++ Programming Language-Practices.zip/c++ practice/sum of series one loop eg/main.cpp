#include <iostream>

using namespace std;

int main()
{
    ///1/1+1/2+1/3+1/4+1/5+
    float counter, sum=0;
    int terms;

    cout<<"Enter the terms to calculate its sum:    ";
    cin>>terms;

    for (counter=1; counter<=terms; counter++)
    {
        sum = sum +(1/ counter);
    }
    cout<<"\nThe sum of your series is:    "<<sum;


    return 0;
}
