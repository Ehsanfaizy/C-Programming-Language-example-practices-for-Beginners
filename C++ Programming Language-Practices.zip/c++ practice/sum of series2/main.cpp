#include <iostream>

using namespace std;

int main()
{
    ////// 1/1!+1/3!+1/4!+1/5!+....

    float counter, sum = 0;
    int terms;
    float factorial = 1;

    cout<<"Enter the number of term to calculate the sum of the series:    ";
    cin>>terms;

    for (counter=1; counter<=terms; counter++)
    {
        factorial = factorial * counter;
        sum = sum + (1/factorial);
    }
    cout<<"\nThe sum of series is equal to :   "<<sum;


    return 0;
}
