    #include <iostream>

using namespace std;

int main()
{
    float number1, number2, result;
    char choice;

    cout<<"Enter your first number:   ";
    cin>>number1;

    cout<<"\nEnter your second number:   ";
    cin>>number2;
    cout<<"\n\n\n";

    cout<<"1.............Press + to for addition operation ........."<<endl;
    cout<<"2.............Press - to for subtraction operation ......"<<endl;
    cout<<"3.............Press * for multiplication operation........"<<endl;
    cout<<"4.............Press / for division operation.............."<<endl;
    cin>>choice;

    switch (choice)
    {
    case '+':
        result = number1 + number2;
        cout<<"\nThe result of addition operation is:    "<<result;
        break;
    case '-':
        result = number1 - number2;
        cout<<"\nThe result of subtraction operation is:    "<<result;
        break;
    case '*':
         result = number1 * number2;
        cout<<"\nThe result of multiplication operation is:    "<<result;
        break;
    case '/':
         result = number1 / number2;
        cout<<"\nThe result of division operation is:    "<<result;
        break;
    default:
        cout<<"\nYou have entered wrong choice, Please valid choice + - * /";
    }
    return 0;
}

