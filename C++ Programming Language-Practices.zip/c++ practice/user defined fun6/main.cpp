#include <iostream>
using namespace std;
void leapyear(int);
int main()
{
    int year;
    cout<<"Enter the year:      ";
    cin>>year;

    leapyear(year);
    cout<<"\nI am back in main() fun";
    return 0;
}
void leapyear(int a)
{
   if (a%4 == 0)
        cout<<"\nThe year is leap year";
   else
    cout<<"\nNot leap year";
}
