#include <iostream>
using namespace std;
void fact(int);
int main()
{
    int number;
    cout<<"Enter number to cal its factorial:    ";
    cin>>number;

    fact(number);
    return 0;
}
void fact(int number)
{
    int result=1;
    for (int i = 1; i<=number; i++)
    {
        result = result * i;
    }
    cout<<"\nThe factorial calculated is:   "<<result;
}
