#include <iostream>

using namespace std;

int main()
{
   int myNumber; //This instruction will create a variable myNumber of type integer
   float myFloatingNumber;//This instruction create a variable myfloatingNumber of type float
   char myCharactter;// This instruction will create a variable myCharacter of types character
   string myString;

   /*myString = "I need this to do my MS Degree in UK\n";
   myNumber = 20000;
   myFloatingNumber = 2.8;
   myCharactter = 'B';*/

   cout<<"enter your goal: ";
   cin>>myString;

   cout<<"\nHow much money do you need: ";
   cin>>myNumber;

   cout<<"\nwhich grade: ";
   cin>>myCharactter;

   cout<<"\nGPA: ";
   cin>>myFloatingNumber;


   cout<<myString<<endl;
   cout<<myNumber<<endl;
   cout<<myCharactter<<endl;
   cout<<myFloatingNumber;



    return 0;
}
