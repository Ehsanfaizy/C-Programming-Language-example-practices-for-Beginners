#include <iostream>
#include <stdlib.h>

using namespace std;

int main()
{
    int positives = 0, negatives = 0, zeroes = 0;
    int number;
    char choice = 'Y';
    while(choice == 'y' || choice =='Y')
    {
        system("cls");
        cout<<"Enter any integer:    ";
        cin>>number;

        if (number<0)
            negatives++;
        else if (number>0)
             positives++;
        else
            zeroes++;
        cout<<"\n\nDo you whish to continue ?? (Press Y for yes or press N for no)";
        cin>>choice;
    }
    cout<<"\nThe count of positives numbers entered were "<<positives;
    cout<<"\nThe count of negative numbers entered were  "<<negatives;
    cout<<"\nThe count of zeroes numbers entered weere   "<<zeroes;
    cout<<"\nThe program will terminate now.......";



    return 0;
}
