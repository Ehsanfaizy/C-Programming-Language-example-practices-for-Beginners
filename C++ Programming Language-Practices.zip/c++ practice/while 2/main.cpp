#include <iostream>

using namespace std;

int main()
{
    int a = 1;
    while(a <= 10000)
    {
        cout<<a<<endl;
        a++;
    }





    return 0;
}
