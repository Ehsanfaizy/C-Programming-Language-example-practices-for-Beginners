#include <iostream>

using namespace std;

int main()
{
    int a = 1;
    while (a <= 10)
    {
        cout<<"Step by Step move on! Just move on day by day\n";
        a++;
    }
    return 0;
}
