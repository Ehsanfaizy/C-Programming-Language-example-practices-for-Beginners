#include <iostream>

using namespace std;

int main()
{
    int a = 0;
    while(a <+ 50)
    {
        cout<<a<<endl;
        a = a + 2;
    }
    return 0;
}
